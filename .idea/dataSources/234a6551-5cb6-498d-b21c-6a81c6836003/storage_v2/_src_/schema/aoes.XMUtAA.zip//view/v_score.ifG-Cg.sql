create definer = root@localhost view v_score as
select sum(`aoes`.`achievement`.`score`)       AS `grade`,
       `aoes`.`achievement`.`user_id`          AS `user_id`,
       `aoes`.`achievement`.`exam_id`          AS `exam_id`,
       max(`aoes`.`achievement`.`create_time`) AS `create_time`,
       max(`aoes`.`achievement`.`teacher_id`)  AS `teacher_id`
from `aoes`.`achievement`
group by `aoes`.`achievement`.`user_id`, `aoes`.`achievement`.`exam_id`
order by `create_time` desc;

